<?php
/* $Id: thwbnews.php,v 1.4 2002/11/06 20:43:45 pbaecher Exp $ */

/*
 *  
 *  ThWboard News
 *
 *  WARNING: This script requires thwboard beta 2.8+
 *
 *  This is a basic newsscript using thwboard as news database.
 *  In order to use this script, you need to create a news board,
 *  and enter its ID below. You can post news by creating a new
 *  thread in this board and your users may comment these news
 *  by posting replies (optional)
 *
 *  To alter the layout/design you can edit the variable
 *  $tpl_newsrow. This is the template for a news item.
 *
 *  Then, simply include() this script on your main page. 
 *
 *
 *
 *  (c) 2002 ThWboard Development Team
 */

/* ----------------- config -------------------
   path to your thwboard directory (relative to this script)
   don't forget the slash at the end! */
$thwbpath                       = 'path_to_thwb/';

/* should this script open a MySQL connection?
   1 - yes
   0 - no, use existing */
$mysqlconnect					= 1;

/* print() news directly or store them in $news_output?
   1 - print() news
   0 - store output in $news_output */
$print_news						= 1;

/* news are taken from this boardid */
$boardid                        = 1;

/* amout of news to display at a time */
$newscount                      = 10;

/* dont display more than $maxchars, link to the thread instead. 0 to disable */
$maxchars						= 30;

/* the date format for your news -- see www.php.net/date */ 
$date_format					= 'd.m.Y';

/* newsrow template. available inserts:
   {date}, {topic}, {text}, {author}, {commentcount}, {threadid}, {more} */
$tpl_newsrow = '
<b>{topic}</b><br>
<font size="1">{date} - {commentcount} <a href="'.$thwbpath.'showtopic.php?threadid={threadid}">Kommentar(e)</a></font><br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>{text}</td>
  </tr>
</table>
{more}<br>
<br><br>
';

/* ------------ configuration end --------------------- */


require($thwbpath.'inc/config.inc.php');
require($thwbpath.'inc/thwbcode.inc.php');

if( $mysqlconnect )
{
	mysql_connect($mysql_h, $mysql_u, $mysql_p);
	mysql_select_db($mysql_db);
}

$oldquotes = get_magic_quotes_runtime();
set_magic_quotes_runtime(0);

/* select threads */
$r_thread = mysql_query('SELECT
		threadid,
		threadtopic,
		threadtime,
		threadauthor,
		threadreplies,
		threadcreationtime
	FROM '.$pref.'thread WHERE boardid='.$boardid.' ORDER BY threadcreationtime DESC LIMIT '.$newscount);

$a_thread = array();
$a_threadid = array();
while( $thread = mysql_fetch_array($r_thread) )
{
	$a_thread[$thread['threadid']] = $thread;
	$a_threadid[] = $thread['threadid'];
}
mysql_free_result($r_thread);


/* select postids */
$r_post = mysql_query('SELECT
		threadid,
		postid
	FROM '.$pref.'post WHERE threadid IN('.implode(',', $a_threadid).') ORDER BY posttime DESC');
$a_postid = array();
while( $post = mysql_fetch_array($r_post) )
	$a_postid[$post['threadid']] = $post['postid'];
mysql_free_result($r_post);


/* select posttexts */
$r_post = mysql_query('SELECT
		threadid,
		posttext
	FROM '.$pref.'post WHERE postid IN('.implode(',', $a_postid).')');
while( $post = mysql_fetch_array($r_post) )
	$a_thread[$post['threadid']]['posttext'] = $post['posttext'];
mysql_free_result($r_post);



$news_output = '';
while( list(, $thread) = each($a_thread) )
{
	if( $maxchars && strlen($thread['posttext']) > $maxchars )
	{
		$newtext = substr($thread['posttext'], 0, $maxchars);
		for( $i = $maxchars; $i < strlen($thread['posttext']); $i++ )
		{
			if( $thread['posttext'][$i] == ' ' || $thread['posttext'][$i] == "\n" )
				break;
			$newtext .= $thread['posttext'][$i];			
		}
		$more = '[<a href="'.$thwbpath.'showtopic.php?threadid='.$thread['threadid'].'">more</a>]';
		$thread['posttext'] = $newtext;
	}
	else
	{
		$more = '';
	}

	$row = $tpl_newsrow;
	$row = str_replace('{more}', $more, $row);
	$row = str_replace('{topic}', parse_code($thread['threadtopic']), $row);
	$row = str_replace('{text}', parse_code($thread['posttext'], 1, 1, 1, 1), $row);
	$row = str_replace('{author}', $thread['threadauthor'], $row);
	$row = str_replace('{date}', date($date_format, $thread['threadcreationtime']), $row);
	$row = str_replace('{threadid}', $thread['threadid'], $row);
	$row = str_replace('{commentcount}', $thread['threadreplies'], $row);

	
	$news_output .= $row;
}

unset($a_thread);
set_magic_quotes_runtime($oldquotes);

if( $print_news )
	print $news_output;
?>