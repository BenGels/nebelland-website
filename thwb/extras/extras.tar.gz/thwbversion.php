<?php
/* $Id: thwbversion.php,v 1.3 2003/01/13 13:50:01 dkreuer Exp $ */
/*
          ThWboard - PHP/MySQL Bulletin Board System
        ==============================================
            (c) 2000, 2001 by
               Paul Baecher         <paul@thewall.de>
               Felix Gonschorek   <funner@thewall.de>

          download the latest version:
            http://www.thwboard.de

          This  program is  free  software;  you can
          redistribute it and/or modify it under the
          terms of the GNU General Public License as
          published by the Free Software Foundation;
          either  version 2 of  the License,  or (at
          your option) any later version.

        ==============================================

*/

/*      Version-Checker       */

// Config-Bereich | Modify to your needs

$config['relpathtothwb'] = '../';	// Do not forget the trailing slash!

// Ab hier nichts mehr �ndern | Do not change the code below this!

class cVersionSystem
{
	var $_thwbversion;
	var $_thwbpath;
	var $_lasterror;
	
	function cVersionSystem( $relPathToInstThWb )
	{
		global $pref;
		$r_version = mysql_query("SELECT keyvalue FROM " . $pref . "registry WHERE keyname = 'version'");
		if( mysql_num_rows($r_version) == 0 )
		{
			print("Error in database! No valid version!");
			exit;
		}
		$version = mysql_fetch_array($r_version);
		$this->_thwbversion = $version['keyvalue'];
		$this->_thwbpath = $relPathToInstThWb;
	}
	
	function getMD5local( $filename )
	{
		return md5_file( $this->_thwbpath . $filename );
	}
	
	function getMD5remote( $filename )
	{
		$version = file("http://www.thwboard.de/versioncheck.php?version=" . $this->_thwbversion . "&file=" . $filename);
		$version = trim($version[0]);
		if( $version == 'error_exist' )
		{
			$this->_lasterror = $version;
			return 0;
		}
		else
		{
			$this->_lasterror = '';
			return $version;
		}
	}
	
	function getError()
	{
		switch( $this->_lasterror )
		{
			case "error_exist":
				return "Error 0: File requestet does not exist in given version!";
				break;
			default:
				return 1;
		}
	}
}

class cDataCon
{
	var $_dbcon;
	function cDataCon( $db_h = 'localhost', $db_u = 'root', $db_p = '', $db_db = 'thwboard' )
	{
		if( str_replace(".", "", phpversion()) >= '420' )
		{
			$db_new = 1;
		}
		else
		{
			$db_new = 0;
		}
		$mysql = @mysql_connect( $db_h, $db_u, $db_p, $db_new );
		$db = @mysql_select_db( $db_db );
		unset( $db_h, $db_u, $db_p, $db_db, $db_new );
		if( !$mysql || !$db )
		{
			print("MySQL-Connection failed!");
			exit;
		}
		$this->_dbcon = $mysql;
	}
}

$config['cutFiles'] = array(
	'inc/config.inc.php'
	);

function retrieveDirs($rootdirpath)
{
 if ($dir = @opendir($rootdirpath))
 {
   //$array[] = $rootdirpath;
   while (($file = readdir($dir)) !== false)
   {
     if (is_dir($rootdirpath."/".$file) && $file != "." && $file != "..")
     {
       $array = array_merge($array, retrieveDirs($rootdirpath."/".$file."/"));
     }
     else
     {
     	if( $file != "." && $file != ".." )
     	{
     	 $array[] = $rootdirpath . "/" . $file;
     	}
     }
   }
   closedir($dir);
 }
 return $array;
}

function remove_base( &$item1, $key )
{
	$item1 = str_replace("..//", "", $item1);
	$item1 = str_replace("//", "/", $item1);
}

function remove_cvs( &$item1, $key, $array )
{
	if( stristr($item1, "CVS") )
	{
		unset($array[$key]);
	}
}

function getFilesArray( $rootdirpath )
{
	$array = retrieveDirs( $rootdirpath );
	$array = array_reverse($array);
	array_pop($array);
	$array = array_reverse($array);

	array_walk($array, 'remove_cvs', &$array);	
	array_walk($array, 'remove_base');

	return $array;
}

print '<html><head><title>ThWboard Version Check</title></head><body bgcolor="#ffffff" text="#000000"><h1>ThWboard Version Check</h1><p>';
print '<font size="-1">';
print 'Load config ...';

if( !@include($config['relpathtothwb'] . 'inc/config.inc.php') )
{
	print '<br>Das Forum ist noch nicht installiert! Klicken Sie <a href="' . $config['relpathtothwb'] . 'admin/install.php">hier</a>, um mit der Installation zu beginnen.';
	exit;
}

print '.. done<br>';
print 'Open database connection ...';
$C_DataCon = new cDataCon( $mysql_h, $mysql_u, $mysql_p, $mysql_db );
print '.. done<br>';
print 'Starting VersionSystem ...';
$C_Version = new cVersionSystem( $config['relpathtothwb'] );
print '.. done<br>';

if( isset($_GET['file']) )
{
	print 'Load selected file information ...';
	$a_filestocheck = array($_GET['file']);
	print ' .. done<br>';
}
else
{
	print 'Load local file information ...';
	$a_filestocheck = getFilesArray( $config['relpathtothwb'] );
	print '.. done<br>';
}
$modcount = 0;
foreach( $a_filestocheck as $item )
{
	print "checking .. " .$item;
	if( $C_Version->getMD5local($item) == $C_Version->getMD5remote($item) )
	{
		print " .. <font color=\"#00A000\">ok</font><br>";
	}
	else
	{
		print " .. <font color=\"#A00000\">modified or not correct version</font><br>";
		$modcount++;
	}
}
print "<br>";
print "Files modified or wrong version: <b>" . $modcount . "</b> of total <b>" . count($a_filestocheck) . "</b> files.";
print "</body></html>";
?>