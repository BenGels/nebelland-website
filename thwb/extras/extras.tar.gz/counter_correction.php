<?php
// this script updates the thread/post count values of all boards
// useful if you guess something is screwed up

include '../inc/config.inc.php';

mysql_connect($mysql_h, $mysql_u, $mysql_p);
mysql_select_db($mysql_db);

if( !$offset )
{
	$offset = 0;
}
else
{
  $offset = intval($offset);
}

$r_board = mysql_query("SELECT boardid, boardposts, boardthreads, boardname FROM ".$pref."board ORDER BY boardid LIMIT $offset, 1");
if( mysql_num_rows($r_board) == 0  )
{
	print 'all boards updated.';
	exit;
}

$board = mysql_fetch_array($r_board);

print '*** Board: ' . $board['boardname'] . ' - ' . $board['boardthreads'] . ' threads, ' . $board['boardposts'] . ' posts<br>';

$threads = 0;
$posts = 0;

$r_thread = mysql_query("SELECT threadreplies FROM ".$pref."thread WHERE boardid=$board[boardid]");
while( $thread = mysql_fetch_array($r_thread) )
{
	$threads++;
	$posts += $thread['threadreplies'] + 1;
}

print '*** NEW VALUES: ' . $threads . ' threads, ' . $posts . ' posts<br><br>';

mysql_query("UPDATE ".$pref."board SET boardthreads=$threads, boardposts=$posts WHERE boardid=$board[boardid]");

print '<a href="counter_correction.php?offset=' . ++$offset . '">update next board</a>';


?>